﻿namespace UiPath.Shared.Localization
{
    internal class SharedResources : EN.ImageDownloader.Activities.Properties.Resources
    {
    }
}