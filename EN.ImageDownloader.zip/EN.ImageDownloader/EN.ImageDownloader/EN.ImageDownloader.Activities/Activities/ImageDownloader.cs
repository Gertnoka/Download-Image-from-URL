using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using EN.ImageDownloader.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using System.Net;

namespace EN.ImageDownloader.Activities
{
    [LocalizedDisplayName(nameof(Resources.ImageDownloader_DisplayName))]
    [LocalizedDescription(nameof(Resources.ImageDownloader_Description))]
    public class ImageDownloader : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.ImageDownloader_PhotoURL_DisplayName))]
        [LocalizedDescription(nameof(Resources.ImageDownloader_PhotoURL_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> PhotoURL { get; set; }

        [LocalizedDisplayName(nameof(Resources.ImageDownloader_LocalPath_DisplayName))]
        [LocalizedDescription(nameof(Resources.ImageDownloader_LocalPath_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> LocalPath { get; set; }

        #endregion


        #region Constructors

        public ImageDownloader()
        {
        }


        public static void downloadFile(string URL , string localPath)
        {
            WebClient webClient = new WebClient();
            webClient.DownloadFile($"{URL}", localPath);
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (PhotoURL == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(PhotoURL)));
            if (LocalPath == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(LocalPath)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var photoURL = PhotoURL.Get(context);
            var localPath = LocalPath.Get(context);
    

            // Add execution logic HERE
            ImageDownloader.downloadFile(photoURL, localPath);

            // Outputs
            return (ctx) => {
            };
        }

        #endregion
    }
}

