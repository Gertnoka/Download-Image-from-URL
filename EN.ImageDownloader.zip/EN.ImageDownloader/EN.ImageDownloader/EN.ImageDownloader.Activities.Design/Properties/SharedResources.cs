﻿namespace UiPath.Shared.Localization
{
    internal class SharedResources : EN.ImageDownloader.Activities.Design.Properties.Resources
    {
    }
}