using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using EN.ImageDownloader.Activities.Design.Designers;
using EN.ImageDownloader.Activities.Design.Properties;

namespace EN.ImageDownloader.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(ImageDownloader), categoryAttribute);
            builder.AddCustomAttributes(typeof(ImageDownloader), new DesignerAttribute(typeof(ImageDownloaderDesigner)));
            builder.AddCustomAttributes(typeof(ImageDownloader), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
