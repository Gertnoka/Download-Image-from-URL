namespace EN.ImageDownloader.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for ImageDownloaderDesigner.xaml
    /// </summary>
    public partial class ImageDownloaderDesigner
    {
        public ImageDownloaderDesigner()
        {
            InitializeComponent();
        }
    }
}
