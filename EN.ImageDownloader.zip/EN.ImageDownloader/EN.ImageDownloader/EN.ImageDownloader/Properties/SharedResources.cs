﻿namespace UiPath.Shared.Localization
{
    internal class SharedResources : EN.ImageDownloader.Properties.Resources
    {
    }
}